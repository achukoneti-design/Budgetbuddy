
# BudgetBuddy - Next.js

This is a mobile-first Next.js demo app (BudgetBuddy) containing:
- Dashboard, Tax Calculator, Property Finder, Finances pages
- API routes: /api/generate-report (OpenAI-capable) and /api/tax
- Local profile persistence using localStorage
- Tailwind CSS for styling

## Quick start

1. `npm install`
2. (optional) create `.env.local` with `OPENAI_API_KEY=sk-...`
3. `npm run dev`
4. Open http://localhost:3000

## Deploy

- Upload the ZIP to Vercel or push to GitHub and import on Vercel.
- Add `OPENAI_API_KEY` as a project environment variable to enable AI reports.
