import Link from 'next/link';
import { useRouter } from 'next/router';

export default function Layout({ children }) {
  const router = useRouter();
  const navItems = [
    { href: '/dashboard', label: 'Dashboard' },
    { href: '/tax-calculator', label: 'Tax Calculator' },
    { href: '/property-finder', label: 'Property Finder' },
    { href: '/finances', label: 'Finances' },
  ];

  return (
    <div className="min-h-screen flex">
      <aside className="w-56 bg-slate-800 text-white p-4 flex flex-col">
        <h2 className="font-bold text-lg mb-4">BudgetBuddy</h2>
        <nav className="flex-1 space-y-2">
          {navItems.map((item) => (
            <Link key={item.href} href={item.href}>
              <a className={`block p-2 rounded ${router.pathname === item.href ? 'bg-slate-600' : 'hover:bg-slate-700'}`}>
                {item.label}
              </a>
            </Link>
          ))}
        </nav>
        <footer className="text-xs mt-4">Built by Achyuth Koneti</footer>
      </aside>
      <main className="flex-1 p-4 bg-gray-50">{children}</main>
    </div>
  );
}
