import Layout from '../components/Layout';
import { useState, useEffect } from 'react';

export default function PropertyFinder() {
  const [postcode, setPostcode] = useState('');
  const [budget, setBudget] = useState('');

  useEffect(()=>{
    try { const saved = localStorage.getItem('budgetbuddy_profile'); if(saved){ const p=JSON.parse(saved); setPostcode(p.searchPostcode||''); setBudget(p.maxPropertyBudget||''); } } catch(e){}
  },[]);

  function buildRightmoveURL() {
    const location = postcode || '';
    const maxPrice = budget || '';
    return `https://www.rightmove.co.uk/property-for-sale/find.html?searchLocation=${encodeURIComponent(location)}&maxPrice=${maxPrice}`;
  }

  return (
    <Layout>
      <h1 className="text-2xl font-bold mb-4">Property Finder</h1>
      <div className="flex gap-2 mb-4">
        <input value={postcode} onChange={e=>setPostcode(e.target.value)} placeholder="Postcode or town" className="border p-2 rounded" />
        <input value={budget} onChange={e=>setBudget(e.target.value)} placeholder="Max price" className="border p-2 rounded" />
        <a href={buildRightmoveURL()} target="_blank" rel="noreferrer" className="bg-blue-600 text-white px-4 py-2 rounded">Open Rightmove</a>
      </div>
      <div>
        <button className="px-4 py-2 border rounded" onClick={()=>{ const saved=JSON.parse(localStorage.getItem('budgetbuddy_profile')||'{}'); saved.searchPostcode=postcode; saved.maxPropertyBudget=budget; localStorage.setItem('budgetbuddy_profile', JSON.stringify(saved)); alert('Saved to profile locally'); }}>Save to profile</button>
      </div>
    </Layout>
  );
}
