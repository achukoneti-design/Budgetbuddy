export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  const profile = req.body?.profile || {};

  const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
  if (!OPENAI_API_KEY) {
    const fallback = `OPENAI_API_KEY not configured. Example suggestions:\n- Build 3 months emergency fund.\n- Maximise workplace pension contributions to get employer match and tax relief.\n- Use ISAs for tax-free savings.\n- For complex tax planning consult a qualified adviser.`;
    return res.status(200).json({ report: fallback });
  }

  // Call OpenAI Chat Completions (server-side using fetch)
  try {
    const prompt = `You are a friendly UK personal finance adviser. The user profile is: ${JSON.stringify(profile)}. Provide a concise, actionable plan covering: how to reach savings goals, tax-advantaged accounts to use (ISAs, pensions), monthly budget suggestions, and a short legal disclaimer.`;
    const resp = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${OPENAI_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [{ role: 'system', content: 'You are a helpful UK personal finance assistant.' }, { role: 'user', content: prompt }],
        max_tokens: 700,
        temperature: 0.2
      })
    });
    const data = await resp.json();
    const text = data?.choices?.[0]?.message?.content || 'No content from AI.';
    return res.status(200).json({ report: text });
  } catch (err) {
    console.error('AI error', err);
    return res.status(500).json({ report: 'AI generation failed on the server.' });
  }
}
