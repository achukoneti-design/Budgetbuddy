export default function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  const { income } = req.body;
  const gross = Number(income) || 0;

  const personalAllowance = 12570;
  let taxable = Math.max(0, gross - personalAllowance);
  let incomeTax = 0;

  if (taxable > 0) {
    const basicBand = Math.min(50270 - personalAllowance, taxable);
    incomeTax += basicBand * 0.2;
    if (taxable > basicBand) {
      const higher = Math.min(125140 - 50270, taxable - basicBand);
      incomeTax += higher * 0.4;
      if (taxable > basicBand + higher) {
        const additional = taxable - basicBand - higher;
        incomeTax += additional * 0.45;
      }
    }
  }

  const ni = gross > 12570 ? (gross - 12570) * 0.12 : 0;
  const net = Math.round(gross - incomeTax - ni);

  res.json({ gross: Math.round(gross), incomeTax: Math.round(incomeTax), ni: Math.round(ni), net });
}
