import Layout from '../components/Layout';
import { useState } from 'react';

export default function TaxCalculator() {
  const [income, setIncome] = useState('30000');
  const [result, setResult] = useState(null);

  async function calculate() {
    const res = await fetch('/api/tax', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ income })
    });
    const data = await res.json();
    setResult(data);
  }

  return (
    <Layout>
      <h1 className="text-2xl font-bold mb-4">Income Tax Calculator</h1>
      <div className="flex gap-2">
        <input type="number" value={income} onChange={e=>setIncome(e.target.value)} className="border p-2 rounded" />
        <button onClick={calculate} className="bg-slate-800 text-white px-4 py-2 rounded">Calculate</button>
      </div>

      {result && (
        <div className="mt-4 bg-white p-4 rounded shadow">
          <p><strong>Gross:</strong> £{result.gross}</p>
          <p><strong>Income Tax:</strong> £{result.incomeTax}</p>
          <p><strong>National Insurance:</strong> £{result.ni}</p>
          <p><strong>Net Income:</strong> £{result.net}</p>
        </div>
      )}
    </Layout>
  );
}
