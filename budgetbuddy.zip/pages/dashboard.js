import Layout from '../components/Layout';
import { useState, useEffect } from 'react';

export default function Dashboard() {
  const [profile, setProfile] = useState(null);
  const [report, setReport] = useState('');

  useEffect(() => {
    try {
      const saved = localStorage.getItem('budgetbuddy_profile');
      setProfile(saved ? JSON.parse(saved) : { name:'', grossIncomeAnnual: 0, savingsGoals: [] });
    } catch (e) {
      setProfile({ name:'', grossIncomeAnnual: 0, savingsGoals: [] });
    }
  }, []);

  async function fetchReport() {
    setReport('Generating...');
    try {
      const res = await fetch('/api/generate-report', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ profile }) });
      const data = await res.json();
      setReport(data.report);
    } catch (e) {
      setReport('Could not generate AI report.');
    }
  }

  return (
    <Layout>
      <div className="bg-white rounded-2xl p-6 shadow">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Dashboard</h1>
            <p className="text-sm text-slate-600">Overview of your finances</p>
          </div>
          <div className="text-right">
            <div className="text-sm text-slate-500">Welcome</div>
          </div>
        </div>

        <div className="mt-6">
          <button onClick={fetchReport} className="px-4 py-2 bg-emerald-600 text-white rounded">Generate AI Plan</button>
        </div>

        {report && (
          <div className="mt-4 p-4 bg-slate-50 rounded text-sm whitespace-pre-line">{report}</div>
        )}
      </div>
    </Layout>
  );
}
