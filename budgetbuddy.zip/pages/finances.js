import Layout from '../components/Layout';
import { useState, useEffect } from 'react';

const defaultProfile = {
  name: '',
  grossIncomeAnnual: '',
  pensionPercent: 0,
  monthlyBills: 0,
  savingsGoals: [{ name: 'Emergency fund', amount: 1000, targetMonths: 3 }],
  wantsPropertySearch: false,
  searchPostcode: '',
  maxPropertyBudget: null
};

export default function Finances() {
  const [profile, setProfile] = useState(defaultProfile);

  useEffect(()=>{
    try { const saved = localStorage.getItem('budgetbuddy_profile'); if(saved) setProfile(JSON.parse(saved)); } catch(e){}
  },[]);

  function update(field, value){ setProfile(p=>({...p, [field]: value})); }
  function addGoal(){ setProfile(p=>({...p, savingsGoals: [...p.savingsGoals, {name:'New goal', amount:0, targetMonths:3}]})); }
  function save(){ localStorage.setItem('budgetbuddy_profile', JSON.stringify(profile)); alert('Saved locally'); }
  function reset(){ localStorage.removeItem('budgetbuddy_profile'); setProfile(defaultProfile); alert('Profile reset'); }

  return (
    <Layout>
      <h1 className="text-2xl font-bold mb-4">Finances</h1>
      <label className="block text-xs">Name</label>
      <input value={profile.name} onChange={e=>update('name', e.target.value)} className="border p-2 rounded w-full mb-2" />
      <label className="block text-xs">Gross annual income (£)</label>
      <input type="number" value={profile.grossIncomeAnnual} onChange={e=>update('grossIncomeAnnual', e.target.value)} className="border p-2 rounded w-full mb-2" />
      <label className="block text-xs">Pension contributions (%)</label>
      <input type="number" value={profile.pensionPercent} onChange={e=>update('pensionPercent', Number(e.target.value))} className="border p-2 rounded w-full mb-2" />
      <label className="block text-xs">Monthly bills (£)</label>
      <input type="number" value={profile.monthlyBills} onChange={e=>update('monthlyBills', Number(e.target.value))} className="border p-2 rounded w-full mb-2" />

      <label className="flex items-center gap-2"><input type="checkbox" checked={profile.wantsPropertySearch} onChange={e=>update('wantsPropertySearch', e.target.checked)} /> Enable property search</label>

      {profile.wantsPropertySearch && (
        <div className="mt-2">
          <label className="block text-xs">Search postcode / town</label>
          <input value={profile.searchPostcode} onChange={e=>update('searchPostcode', e.target.value)} className="border p-2 rounded w-full mb-2" />
          <label className="block text-xs">Max property budget (£)</label>
          <input type="number" value={profile.maxPropertyBudget||''} onChange={e=>update('maxPropertyBudget', e.target.value?Number(e.target.value):null)} className="border p-2 rounded w-full mb-2" />
        </div>
      )}

      <div className="mt-3">
        <h3 className="font-semibold">Savings goals</h3>
        {profile.savingsGoals.map((g,i)=> (
          <div key={i} className="p-2 border rounded my-2">
            <input className="w-full p-1 mb-1" value={g.name} onChange={e=>{ const copy=[...profile.savingsGoals]; copy[i].name=e.target.value; update('savingsGoals', copy); }} />
            <div className="flex gap-2">
              <input className="flex-1 p-1" value={g.amount} onChange={e=>{ const copy=[...profile.savingsGoals]; copy[i].amount=Number(e.target.value); update('savingsGoals', copy); }} />
              <input className="w-20 p-1" value={g.targetMonths} onChange={e=>{ const copy=[...profile.savingsGoals]; copy[i].targetMonths=Number(e.target.value); update('savingsGoals', copy); }} />
            </div>
          </div>
        ))}
        <button onClick={addGoal} className="text-sm underline">+ Add goal</button>
      </div>

      <div className="mt-6 flex gap-2">
        <button onClick={save} className="px-4 py-2 bg-emerald-600 text-white rounded">Save</button>
        <button onClick={reset} className="px-4 py-2 border rounded">Reset</button>
      </div>
    </Layout>
  );
}
